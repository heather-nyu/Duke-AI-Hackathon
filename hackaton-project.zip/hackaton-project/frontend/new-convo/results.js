// Get the query string from the URL
const queryString = window.location.search;

// Create a URLSearchParams object
const urlParams = new URLSearchParams(queryString);

// Access individual parameters
const semesterValue = urlParams.get('semester');
const monthlyBudgetValue = urlParams.get('monthlyBudget');
let westCampusCheckValue = urlParams.get('westCampusCheck');
let eastCampusCheckValue = urlParams.get('eastCampusCheck');
let carCheckValue = urlParams.get('carCheck');
let busCheckValue = urlParams.get('busCheck');
let walkingCheckValue = urlParams.get('walkingCheck');

console.log('values received:', {
	semesterValue,
	monthlyBudgetValue,
	westCampusCheckValue,
	eastCampusCheckValue,
	carCheckValue,
	busCheckValue,
	walkingCheckValue,
});

let westCampusBoolean = westCampusCheckValue == 'on' ? true : false;
let eastCampusBoolean = eastCampusCheckValue == 'on' ? true : false;

let carCheckBoolean = carCheckValue == 'on' ? true : false;
let busCheckBoolean = busCheckValue == 'on' ? true : false;
let walkingCheckBoolean = walkingCheckValue == 'on' ? true : false;

const apiQueryString = new URLSearchParams({
	semesterValue,
	monthlyBudgetValue,
	westCampusCheckValue: westCampusBoolean,
	eastCampusCheckValue: eastCampusBoolean,
	carCheckValue: carCheckBoolean,
	busCheckValue: busCheckBoolean,
	walkingCheckValue: walkingCheckBoolean,
}).toString();

try {
	const response = await fetch(`http://localhost:3000/api/ai/data?${queryString}`);

	console.log('response from api', response);

	if (!response.ok) {
		throw new Error('Network response was not ok');
	}

	const data = await response.text();
	console.log('data', data);

	const resultObject = JSON.parse(data);

	const jsonObject = JSON.parse(data);

	console.log('sources', jsonObject.sources);

	let result = jsonObject.result;

	const splitResult = result.split('```')[1];
	console.log('splitResult', splitResult);

	const { introductoryMessage, results, conclusion } = JSON.parse(splitResult);
	document.getElementById('introductoryMessage').textContent = introductoryMessage;
	document.getElementById('conclusion').textContent = conclusion;

	results.forEach((result) => {
		// address: "1000 McQueen Drive 27705"
		// averageMonthlyRental: "Not specified"
		// name: "The Belmont Luxury Apartments"
		// transportationTime: "Within Duke Vans zone"
		// website: "www.livebelmont.com"

		const resultHTML = `
        <div class="col-xl-3 col-md-6 mb-xl-0 mb-4 mt-2">
            <div class="card card-blog card-plain">
                <div class="position-relative">
                    <a class="d-block shadow-xl border-radius-xl">
                        <img src="../assets/img/home-decor-1.jpg" alt="img-blur-shadow"
                            class="img-fluid shadow border-radius-xl">
                    </a>
                </div>
                <div class="card-body px-1 pb-0">
                    <p class="text-gradient text-dark mb-2 text-sm">Project #1</p>
                    <h5>
                        ${result.name}
                    </h5>
                    </a>
                    <div class="mb-4 text-sm">
                        <ul>
                            <li><b>Cost:</b> ${result.averageMonthlyRental}</li>
                            <li><b>Address:</b>2 ${result.address}</li>
                            <li><b>Transportation time:</b> ${result.transportationTime}</li>
                            <li><b>Link:</b> <a href="${result.website}">Visit property website</a></li>
                        </ul>
                    </div>
                    <div class="d-flex align-items-center justify-content-between">
                        <button type="button" class="btn btn-outline-primary btn-sm mb-0">View
                            Project</button>
                        <div class="avatar-group mt-2">
                            <a href="javascript:;" class="avatar avatar-xs rounded-circle"
                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                title="Elena Morison">
                                <img alt="Image placeholder" src="../assets/img/team-1.jpg">
                            </a>
                            <a href="javascript:;" class="avatar avatar-xs rounded-circle"
                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                title="Ryan Milly">
                                <img alt="Image placeholder" src="../assets/img/team-2.jpg">
                            </a>
                            <a href="javascript:;" class="avatar avatar-xs rounded-circle"
                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                title="Nick Daniel">
                                <img alt="Image placeholder" src="../assets/img/team-3.jpg">
                            </a>
                            <a href="javascript:;" class="avatar avatar-xs rounded-circle"
                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                title="Peterson">
                                <img alt="Image placeholder" src="../assets/img/team-4.jpg">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
`;

		let tempDiv = document.createElement('div');
		tempDiv.innerHTML = resultHTML;

		while (tempDiv.firstChild) {
			document.getElementById('results').appendChild(tempDiv.firstChild);
		}
	});

	// Show results
	document.getElementById('results-container').style.display = 'block';
	document.getElementById('results-container').style.visibility = 'inherit';

	// hide loading
	document.getElementById('loading').style.display = 'none';
	document.getElementById('loading').style.visibility = 'hidden';
} catch (error) {
	document.getElementById('responseOutput').textContent = 'Error fetching data: ' + error;
}
