// Get the query string from the URL
const queryString = window.location.search;

// Create a URLSearchParams object
const urlParams = new URLSearchParams(queryString);

// Access individual parameters
const propertyName = urlParams.get('propertyName');

try {
	const response = await fetch(
		`http://localhost:3000/api/ai/property-details?propertyName=${propertyName}`
	);

	console.log('response from api', response);

	if (!response.ok) {
		throw new Error('Network response was not ok');
	}

	const data = await response.text();

	const resultObject = JSON.parse(data);

	const jsonObject = JSON.parse(data);

	console.log('sources', jsonObject.sources);

	let result = jsonObject.result;

	const splitResult = result.split('```')[1];
	console.log('splitResult', splitResult);

	const {
		introductoryMessage,
		apartmentName,
		URL,
		addresses,
		averageMonthlyRental,
		timeOfTransportation,
		others,
		conclusion,
		proTips,
	} = JSON.parse(splitResult);

	document.getElementById('introductoryMessage').textContent = introductoryMessage;
	document.getElementById('property-name').textContent = apartmentName;
	document.getElementById('url').textContent = URL;
	document.getElementById('addresses').textContent = addresses;
	document.getElementById('property-price').textContent = averageMonthlyRental;
	document.getElementById('timeOfTransportation').textContent = timeOfTransportation;
	document.getElementById('property-description').textContent = others;
	document.getElementById('conclusion').textContent = conclusion;
	document.getElementById('pro-tips').textContent = proTips;
} catch (error) {
	document.getElementById('property-name').textContent = 'Error fetching data: ' + error;
}
