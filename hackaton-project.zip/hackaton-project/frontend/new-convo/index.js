document.getElementById('searchButton').onclick = function () {
	const semesterField = document.getElementById('semester').value;
	const monthlyBudgetField = document.getElementById('monthlyBudget').value;
	const westCampusCheckField = document.getElementById('westCampusCheck').value;
	const eastCampusCheckField = document.getElementById('eastCampusCheck').value;
	const carCheckField = document.getElementById('carCheck').value;
	const busCheckField = document.getElementById('busCheck').value;
	const walkingCheckField = document.getElementById('walkingCheck').value;

	console.log('searchButton', {
		semesterField,
		monthlyBudgetField,
		westCampusCheckField,
		eastCampusCheckField,
		carCheckField,
		busCheckField,
		walkingCheckField,
	});

	location.href = `./results.html?semester=${semesterField}
	&monthlyBudget=${monthlyBudgetField}
	&westCampusCheck=${westCampusCheckField}
	&eastCampusCheck=${eastCampusCheckField}
	&carCheck=${carCheckField}
	&busCheck=${busCheckField}
	&walkingCheck=${walkingCheckField}
	`;
};
