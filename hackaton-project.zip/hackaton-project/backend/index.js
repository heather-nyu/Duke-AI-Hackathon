import axios from 'axios';
import inquirer from 'inquirer';
import express from 'express';
import cors from 'cors';
import fs from 'fs';

import { OpenAI } from 'openai';

// Initialize OpenAI
const openai = new OpenAI({
	apiKey: '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',
	default_headers: { 'OpenAI-Beta': 'assistants=v2' },
});

// Method that creates an OpenAI assistant using File Search RAG tool:
// https://platform.openai.com/docs/assistants/tools/file-search
async function createAssistant(query) {
	const {
		westCampusCheckValue,
		eastCampusCheckValue,
		carCheckValue,
		busCheckValue,
		walkingCheckValue,
	} = query;

	let transportation = '';

	if (carCheckValue == true) {
		transportation = 'Car';
	} else if (busCheckValue == true) {
		transportation = 'Bus';
	} else if (walkingCheckValue == true) {
		transportation = 'Walking';
	} else {
		transportation = 'Bus';
	}

	let campusRegion =
		westCampusCheckValue == true
			? 'West Campus'
			: eastCampusCheckValue == true
			? 'East Campus'
			: 'Any option';

	const prompt = `
    Given the following criteria:
    - Semester Start: ${query.semesterValue}
    - Maximum Monthly Budget: ${query.monthlyBudgetValue}
    - Preferred Method of Transportation: ${transportation}
    - Campus Region: ${campusRegion}

    Use the File-Search tool to find the best apartment options. Return the name of the apartment, website URL, addresses, average monthly rental of the referenced properties, and the time of transportation based on the above criteria.
	Please return the recommendations in JSON format with the keys: introductoryMessage, results, and conclusion. Where the key results may contain multiple entries per each recommendation.
    `;

	return await openai.beta.assistants.create({
		name: 'Semester Planer',
		instructions: prompt,
		model: 'gpt-4o',
		tools: [{ type: 'file_search' }],
	});
}

// 2nd AI Assistant to retrieve property details and
// more tailored recommendations relevant for this property based on collected experiences from the community (how secure it is, hidden costs, network coverage, etc.)
async function createPropertyDetailAssistant(query) {
	const { propertyName } = query;

	const prompt = `
    Given the following criteria:
    - Name of the property: ${propertyName}

    Use the File-Search tool to find the apartment based on its name. Return the name of the apartment, website URL, addresses, average monthly rental of the referenced properties, the time of transportation and any other relevant details along with any Pro tip that will be helful for the prospect tenant.
	Please return the result in JSON format with the keys: introductoryMessage, apartmentName, URL, addresses, averageMonthlyRental, timeOfTransportation, others, conclusion and proTips. Where the key others can include any other relevant information found and the key proTips is a list of tips for the property or other constraints.
    `;

	return await openai.beta.assistants.create({
		name: 'Semester Planer',
		instructions: prompt,
		model: 'gpt-4o',
		tools: [{ type: 'file_search' }],
	});
}

async function searchApartments(assistant) {
	try {
		// RAG data to support lookups for university-specific resources
		// and to support future agentic workflows for distance calculation
		// based on addresses and preferred modes of transportation along with tailored pro tips based on collected data from existing users.
		const fileStreams = [
			'./data-sources/east-central-campus.docx',
			'./data-sources/west-campus.docx',
			'./data-sources/student-affairs.pdf',
			'./data-sources/Apartments around Durham.pdf',
			'./data-sources/Housing.pdf',
			'./data-sources/Pro tip_.docx',
		].map((path) => fs.createReadStream(path));

		// Create a vector store including our two files.
		let vectorStore = await openai.beta.vectorStores.create({
			name: 'Semester Planner vector store',
		});

		await openai.beta.vectorStores.fileBatches.uploadAndPoll(vectorStore.id, {
			files: fileStreams,
		});

		await openai.beta.assistants.update(assistant.id, {
			tool_resources: { file_search: { vector_store_ids: [vectorStore.id] } },
		});

		const thread = await openai.beta.threads.create({
			messages: [
				{
					role: 'user',
					content: `
    Use the File-Search tool to find the best apartment based on its name. Return the name of the apartment, website URL, addresses, average monthly rental of the referenced properties, and the time of transportation based on the above criteria.
	Please return the recommendations in JSON format with the keys: introductoryMessage, results, and conclusion. Where the key results may contain multiple entries per each recommendation.
	`,
				},
			],
		});

		let response = {};

		const run = await openai.beta.threads.runs.createAndPoll(thread.id, {
			assistant_id: assistant.id,
		});

		const messages = await openai.beta.threads.messages.list(thread.id, {
			run_id: run.id,
		});

		const message = messages.data.pop();

		if (message.content[0].type === 'text') {
			const { text } = message.content[0];
			const { annotations } = text;
			const citations = [];

			let index = 0;
			for (let annotation of annotations) {
				text.value = text.value.replace(annotation.text, '[' + index + ']');
				const { file_citation } = annotation;
				if (file_citation) {
					const citedFile = await openai.files.retrieve(file_citation.file_id);
					citations.push('[' + index + ']' + citedFile.filename);
				}
				index++;
			}

			response = {
				result: text.value,
				sources: citations,
			};
		}

		return response;
	} catch (error) {
		console.error(
			'Error in creating assistant:',
			error.response ? error.response.data : error.message
		);
		const response = {
			error: error.response ? error.response.data : error.message,
		};

		return response;
	}
}

// Another custom verctor store to be used to create additional thread ad run to prompt for property details
async function searchPropertyDetails(assistant) {
	try {
		// RAG data to support lookups for university-specific resources
		// and to support future agentic workflows for distance calculation
		// based on addresses and preferred modes of transportation along with tailored pro tips based on collected data from existing users.
		const fileStreams = [
			'./data-sources/east-central-campus.docx',
			'./data-sources/west-campus.docx',
			'./data-sources/student-affairs.pdf',
			'./data-sources/Apartments around Durham.pdf',
			'./data-sources/Housing.pdf',
			'./data-sources/Pro tip_.docx',
		].map((path) => fs.createReadStream(path));

		// Create a vector store including our two files.
		let vectorStore = await openai.beta.vectorStores.create({
			name: 'Semester Planner vector store',
		});

		await openai.beta.vectorStores.fileBatches.uploadAndPoll(vectorStore.id, {
			files: fileStreams,
		});

		await openai.beta.assistants.update(assistant.id, {
			tool_resources: { file_search: { vector_store_ids: [vectorStore.id] } },
		});

		const thread = await openai.beta.threads.create({
			messages: [
				{
					role: 'user',
					content: `				
					Use the File-Search tool to find the apartment based on its ame. Return the name of the apartment, website URL, addresses, average monthly rental of the referenced properties, the time of transportation and any other relevant details along with any Pro tip that will be helful for the prospect tenant.
					Please return the result in JSON format with the keys: introductoryMessage, apartmentName, URL, addresses, averageMonthlyRental, timeOfTransportation, others, conclusion and proTips. Where the key others can include any other relevant information found and the key proTips is a list of tips for the property or other constraints.
					`,
				},
			],
		});

		let response = {};

		const run = await openai.beta.threads.runs.createAndPoll(thread.id, {
			assistant_id: assistant.id,
		});

		const messages = await openai.beta.threads.messages.list(thread.id, {
			run_id: run.id,
		});

		const message = messages.data.pop();

		if (message.content[0].type === 'text') {
			const { text } = message.content[0];
			const { annotations } = text;
			const citations = [];

			let index = 0;
			for (let annotation of annotations) {
				text.value = text.value.replace(annotation.text, '[' + index + ']');
				const { file_citation } = annotation;
				if (file_citation) {
					const citedFile = await openai.files.retrieve(file_citation.file_id);
					citations.push('[' + index + ']' + citedFile.filename);
				}
				index++;
			}

			response = {
				result: text.value,
				sources: citations,
			};
		}

		return response;
	} catch (error) {
		console.error(
			'Error in creating assistant:',
			error.response ? error.response.data : error.message
		);
		const response = {
			error: error.response ? error.response.data : error.message,
		};

		return response;
	}
}

const app = express();
const port = 3000;

app.use(
	cors({
		origin: '*', // Allow requests from any origin
	})
);

app.get('/api/ai/data', async (req, res) => {
	const assistant = await createAssistant(req.query);
	console.log(assistant);
	let response = await searchApartments(assistant);

	const cleanedResult = response.result.replace('json', '').trim();

	const newResponse = {
		result: cleanedResult,
		sources: response.sources,
	};

	console.log('response', newResponse);
	res.send(newResponse);
});

app.get('/api/ai/property-details', async (req, res) => {
	const assistant = await createPropertyDetailAssistant(req.query);
	console.log(assistant);
	let response = await searchPropertyDetails(assistant);

	const cleanedResult = response.result.replace('json', '').trim();

	const newResponse = {
		result: cleanedResult,
		sources: response.sources,
	};

	console.log('response for property details', newResponse);
	res.send(newResponse);
});

app.listen(port, () => {
	console.log(`Server is running on http://localhost:${port}`);
});
